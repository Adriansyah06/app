const express = require("express");
const fileUpload = require("express-fileupload");
let importExcel = require('convert-excel-to-json');

const capitals = require("./routes/capital_route");
const labors = require("./routes/labor_route");
const outputs = require("./routes/output_route");

const port = process.env.PORT || 3000;

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(fileUpload());

app.get('/', (req,res)=>{
	res.sendFile(__dirname+'/views/index.html');
})

app.post('/',(req,res)=>{
	let file = req.files.filename;
	let filename = file.name;
	file.mv('./excel/'+filename,(err)=>{
	if(err){
	res.send('maaf gagal upload');
	}else{
		let result = importExcel({
			sourceFile : './excel/'+filename,
			header :{rows:1}
		});
		res.send(result);
		console.log(result);
	}
});
});


app.use("/capitals", capitals);
app.use("/labors", labors);
app.use("/outputs", outputs);

app.listen(port, () => console.log(`server running on ${port}`));
