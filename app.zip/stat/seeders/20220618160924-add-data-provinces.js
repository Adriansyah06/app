"use strict";

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert("provinces", [
      {
        name: "Aceh",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Sumut",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Sumbar",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Riau",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Jambi",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Sumsel",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Bengkulu",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Lampung",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "DKI",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Jabar",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Jateng",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Yogyakarta",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "jatim",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Bali",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Kalbar",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Kalteng",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Kalsel",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Kaltim",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Sulut",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Sulteng",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Sulsel",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Sultra",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "NTB",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "NTT",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Maluku",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: "Papua",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */

    await queryInterface.bulkDelete("provinces", null, {});
  },
};
