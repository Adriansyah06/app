"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class source extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      models.source.belongsTo(models.province, { foreignKey: "provinceId" });
    }
  }
  source.init(
    {
      provinceId: DataTypes.INTEGER,
      economicGrowth: DataTypes.DECIMAL,
      totalFactor: DataTypes.DECIMAL,
      contributionOfCapitals: DataTypes.DECIMAL,
      contributionOfLabors: DataTypes.DECIMAL,
    },
    {
      sequelize,
      paranoid: true,
      timestamps: true,
      modelName: "source",
    }
  );
  return source;
};
