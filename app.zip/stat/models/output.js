"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class output extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      models.output.belongsTo(models.province, { foreignKey: "provinceId" });
    }
  }
  output.init(
    {
      provinceId: DataTypes.INTEGER,
      year: DataTypes.DECIMAL,
      value: DataTypes.DECIMAL,
    },
    {
      sequelize,
      paranoid: true,
      timestamps: true,
      modelName: "output",
    }
  );
  return output;
};
