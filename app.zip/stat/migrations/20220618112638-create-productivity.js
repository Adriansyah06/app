"use strict";
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("productivities", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      provinceId: {
        allowNull: false,
        type: Sequelize.INTEGER,
        references: {
          model: "provinces",
          key: "id",
        },
      },
      beta: {
        allowNull: false,
        type: Sequelize.DECIMAL,
      },
      alpha: {
        allowNull: false,
        type: Sequelize.DECIMAL,
      },
      sum: {
        allowNull: false,
        type: Sequelize.DECIMAL,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      deletedAt: {
        allowNull: true,
        type: Sequelize.DATE,
      },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable("productivities");
  },
};
