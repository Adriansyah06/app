"use strict";
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("sources", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      provinceId: {
        allowNull: false,
        type: Sequelize.INTEGER,
        references: {
          model: "provinces",
          key: "id",
        },
      },
      economicGrowth: {
        allowNull: false,
        type: Sequelize.DECIMAL,
      },
      totalFactor: {
        allowNull: false,
        type: Sequelize.DECIMAL,
      },
      contributionOfCapitals: {
        allowNull: false,
        type: Sequelize.DECIMAL,
      },
      contributionOfLabors: {
        allowNull: false,
        type: Sequelize.DECIMAL,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      deletedAt: {
        allowNull: true,
        type: Sequelize.DATE,
      },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable("sources");
  },
};
