
const {
  capital,
  labor,
  output,
  productivity,
  province,
  source,
} = require("../models");

class Output {
  async getAllOutputs(req, res, next) {
    try {
      let data = await output.findAll({
        attributes: ["year", "value"],
        include: [
          {
            model: province,
            attributes: ["name"],
          },
        ],
      });

      if (data.length === 0) {
        return res.status(404).json({ errors: ["output not found"] });
      }

      res.status(200).json({ data });
    } catch (error) {
      console.log(error)
      res.status(500).json({ errors: ["Internal Server Error"] });
    }
  }

  async getDetailOutput(req, res, next) {
    try {
      let data = await output.findOne({
        where: { id: req.params.id },
        attributes: ["year", "value"],
        include: [
          {
            model: province,
            attributes: ["name"],
          },
        ],
      });

      if (!data) {
        return res.status(404).json({ errors: ["output not found"] });
      }

      res.status(200).json({ data });
    } catch (error) {
      res.status(500).json({ errors: ["Internal Server Error"] });
    }
  }

  async createOutput(req, res, next) {
    try {
      const newData = await output.create(req.body);

      const data = await output.findOne({
        where: {
          id: newData.id,
        },
        attributes: ["year", "value"],
        include: [
          {
            model: province,
            attributes: ["name"],
          },
        ],
      });

      res.status(201).json({ data });
    } catch (error) {
      console.log(error)
      return res.status(500).json({ errors: ["Internal Server Error"] });
    }
  }

  async updateOutput(req, res, next) {
    try {
      const updatedData = await output.update(req.body, {
        where: {
          id: req.params.id,
        },
      });
      if (updatedData[0] === 0) {
        return res.status(404).json({ errors: ["output not founc"] });
      }

      const data = await output.findOne({
        where: { id: req.params.id },
        attributes: ["year", "value"],
        include: [
          {
            model: province,
            attributes: ["name"],
          },
        ],
      });
      res.status(201).json({ data });
    } catch (error) {
      return res.status(500).json({ errors: ["Internal Server Error"] });
    }
  }

  async deleteOutput(req, res, next) {
    try {
      let data = await output.destroy({ where: { id: req.params.id } });

      if (!data) {
        return res.status(404).json({ errors: ["output not found"] });
      }

      res.status(200).json({ message: "delete success" });
    } catch (error) {
      return res.status(500).json({ errors: ["Internal Server Error"] });
    }
  }
}

module.exports = new Output();
