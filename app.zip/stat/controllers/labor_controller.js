
const {
  capital,
  labor,
  output,
  productivity,
  province,
  source,
} = require("../models");

class Labor {
  async getAllLabors(req, res, next) {
    try {
      let data = await labor.findAll({
        attributes: ["year", "value"],
        include: [
          {
            model: province,
            attributes: ["name"],
          },
        ],
      });

      if (data.length === 0) {
        return res.status(404).json({ errors: ["labor not found"] });
      }

      res.status(200).json({ data });
    } catch (error) {
      res.status(500).json({ errors: ["Internal Server Error"] });
    }
  }

  async getDetailLabor(req, res, next) {
    try {
      let data = await labor.findOne({
        where: { id: req.params.id },
        attributes: ["year", "value"],
        include: [
          {
            model: province,
            attributes: ["name"],
          },
        ],
      });

      if (!data) {
        return res.status(404).json({ errors: ["labor not found"] });
      }

      res.status(200).json({ data });
    } catch (error) {
      res.status(500).json({ errors: ["Internal Server Error"] });
    }
  }

  async createLabor(req, res, next) {
    try {
      const newData = await labor.create(req.body);

      const data = await labor.findOne({
        where: {
          id: newData.id,
        },
        attributes: ["year", "value"],
        include: [
          {
            model: province,
            attributes: ["name"],
          },
        ],
      });

      res.status(201).json({ data });
    } catch (error) {
      return res.status(500).json({ errors: ["Internal Server Error"] });
    }
  }

  async updateLabor(req, res, next) {
    try {
      const updatedData = await labor.update(req.body, {
        where: {
          id: req.params.id,
        },
      });
      if (updatedData[0] === 0) {
        return res.status(404).json({ errors: ["Labor not founc"] });
      }

      const data = await labor.findOne({
        where: { id: req.params.id },
        attributes: ["year", "value"],
        include: [
          {
            model: province,
            attributes: ["name"],
          },
        ],
      });
      res.status(201).json({ data });
    } catch (error) {
      return res.status(500).json({ errors: ["Internal Server Error"] });
    }
  }

  async deleteLabor(req, res, next) {
    try {
      let data = await labor.destroy({ where: { id: req.params.id } });

      if (!data) {
        return res.status(404).json({ errors: ["labor not found"] });
      }

      res.status(200).json({ message: "delete success" });
    } catch (error) {
      return res.status(500).json({ errors: ["Internal Server Error"] });
    }
  }
}

module.exports = new Labor();
