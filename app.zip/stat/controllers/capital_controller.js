
const {
  capital,
  labor,
  output,
  productivity,
  province,
  source,
} = require("../models");

class Capital {
  async getAllCapitals(req, res, next) {
    try {
      let data = await capital.findAll({
        attributes: ["year", "value"],
        include: [
          {
            model: province,
            attributes: ["name"],
          },
        ],
      });

      if (data.length === 0) {
        return res.status(404).json({ errors: ["capital not found"] });
      }

      res.status(200).json({ data });
    } catch (error) {
      res.status(500).json({ errors: ["Internal Server Error"] });
    }
  }

  async getDetailCapital(req, res, next) {
    try {
      let data = await capital.findOne({
        where: { id: req.params.id },
        attributes: ["year", "value"],
        include: [
          {
            model: province,
            attributes: ["name"],
          },
        ],
      });

      if (!data) {
        return res.status(404).json({ errors: ["capital not found"] });
      }

      res.status(200).json({ data });
    } catch (error) {
      res.status(500).json({ errors: ["Internal Server Error"] });
    }
  }

  async createCapital(req, res, next) {
    try {
      const newData = await capital.create(req.body);

      const data = await capital.findOne({
        where: {
          id: newData.id,
        },
        attributes: ["year", "value"],
        include: [
          {
            model: province,
            attributes: ["name"],
          },
        ],
      });

      res.status(201).json({ data });
    } catch (error) {
      return res.status(500).json({ errors: ["Internal Server Error"] });
    }
  }

  async updateCapital(req, res, next) {
    try {
      const updatedData = await capital.update(req.body, {
        where: {
          id: req.params.id,
        },
      });
      if (updatedData[0] === 0) {
        return res.status(404).json({ errors: ["capital not founc"] });
      }

      const data = await capital.findOne({
        where: { id: req.params.id },
        attributes: ["year", "value"],
        include: [
          {
            model: province,
            attributes: ["name"],
          },
        ],
      });
      res.status(201).json({ data });
    } catch (error) {
      return res.status(500).json({ errors: ["Internal Server Error"] });
    }
  }

  async deleteCapital(req, res, next) {
    try {
      let data = await capital.destroy({ where: { id: req.params.id } });

      if (!data) {
        return res.status(404).json({ errors: ["capital not found"] });
      }

      res.status(200).json({ message: "delete success" });
    } catch (error) {
      return res.status(500).json({ errors: ["Internal Server Error"] });
    }
  }
}

module.exports = new Capital();
