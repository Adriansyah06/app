const express = require("express");

const {
  getAllOutputs,
  getDetailOutput,
  createOutput,
  updateOutput,
  deleteOutput,
} = require("../controllers/output_controller");

const router = express.Router();

router.route("/").get(getAllOutputs).post(createOutput);

router
  .route("/:id")
  .get(getDetailOutput)
  .put(updateOutput)
  .delete(deleteOutput);

module.exports = router;
