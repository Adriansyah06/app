const express = require("express");

const {
  getAllLabors,
  getDetailLabor,
  createLabor,
  updateLabor,
  deleteLabor,
} = require("../controllers/labor_controller");

const router = express.Router();

router.route("/").get(getAllLabors).post(createLabor);

router.route("/:id").get(getDetailLabor).put(updateLabor).delete(deleteLabor);

module.exports = router;
