const express = require("express");

const {
  getAllCapitals,
  getDetailCapital,
  createCapital,
  updateCapital,
  deleteCapital,
} = require("../controllers/capital_controller");

const router = express.Router();

router.route("/").get(getAllCapitals).post(createCapital);

router
  .route("/:id")
  .get(getDetailCapital)
  .put(updateCapital)
  .delete(deleteCapital);

module.exports = router;
